#include <linux/init.h>   /* Macros i.e __init __initdata __initconst __exitdata __initref are defined */  
#include <linux/module.h> /* Definition of MODULE_* constants and macros i.e module_int() module_exit() */

MODULE_LICENSE("GPL");    /* Without license kernel build might fail, indicating module is unsafe */

int sample_module_init(void) 
{
	printk(KERN_ALERT "In %s function \n", __FUNCTION__);
/*
 	Note :  printk does not support float 
	0 	KERN_EMERG 	An emergency condition; the system is probably dead
	1 	KERN_ALERT 	A problem that requires immediate attention
	2 	KERN_CRIT 	A critical condition
	3 	KERN_ERR 	An error
	4 	KERN_WARNING 	A warning
	5 	KERN_NOTICE 	A normal, but perhaps noteworthy, condition
	6 	KERN_INFO 	An informational message
	7 	KERN_DEBUG 	A debug message, typically superfluous
	Note : Thers is one more alternative for printk - early_printk

*/
	return 0;
}

void sample_module_exit(void)
{
	printk(KERN_ALERT "In %s function \n", __FUNCTION__);
}

module_init(sample_module_init) /* This is to specify which fun to run when insmod is done*/
module_exit(sample_module_exit) /* This is to specify which fun to run when rmmod is done*/
