# This will use the Generic Makefile present in "/lib/modules/$(uname -r)/build" path to build kernel modules
make -C /lib/modules/$(uname -r)/build M=${PWD} modules
make -C /lib/modules/$(uname -r)/build M=${PWD} clean


# Generated files
modules.order
.modules.order.cmd
Module.symvers
.Module.symvers.cmd
sample.ko --> lodable kernel module
.sample.ko.cmd
sample.mod
sample.mod.c
.sample.mod.cmd
sample.mod.o
.sample.mod.o.cmd
sample.o
.sample.o.cmd


Note : If there is no module init function specified then also insmod will succeed but no action is taken upon module init.
Note : If there is no module exit function specified then it throws rmmod: ERROR saying could not remove module : Device or resource busy

