#include <linux/init.h>     
#include <linux/module.h> 

MODULE_LICENSE("GPL"); 


void sample_module_file2_exit(void)
{
	printk(KERN_ALERT "In %s function \n", __FUNCTION__);
}

module_exit(sample_module_file2_exit) 
