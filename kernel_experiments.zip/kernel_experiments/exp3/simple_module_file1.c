#include <linux/init.h>     
#include <linux/module.h> 

MODULE_LICENSE("GPL");    

int sample_module_file1_init(void) 
{
	printk(KERN_ALERT "In %s function \n", __FUNCTION__);
	return 0;
}


module_init(sample_module_file1_init) 
