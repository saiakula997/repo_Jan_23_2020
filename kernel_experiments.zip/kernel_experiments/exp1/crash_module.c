#include <linux/init.h>
#include <linux/module.h>

MODULE_LICENSE("GPL");


void __init crash_module_fun1(void)   /* __init before a fun will allow this function present in RAM only while module is initializing */ 
{
	printk(KERN_ALERT "In %s function \n", __FUNCTION__);
}

void crash_module_fun2(void) /* Reqular function will exist through out then lifetime of the module */
{
	printk(KERN_ALERT "In %s function \n", __FUNCTION__);
}


int __initdata count = 5; /* __initdata variable will only exist in RAM when module is initializing */ 
int __init crash_module_init(void) /* once initialization happend (crash_module_init, crash_module_fun1) will no longer exist */
{
	while(--count)
		printk(KERN_ALERT "In %s function \n", __FUNCTION__);
	crash_module_fun1(); /* As it is __init function it exist during init of a module */
	crash_module_fun2(); /* As it is reqular function this will execute */
	return 0;
}

void crash_module_exit(void)
{
	printk(KERN_ALERT "In %s function \n", __FUNCTION__);
	crash_module_fun2(); /* As it is reqular function this will execute */
	crash_module_fun1(); /* As it is declared as __init funtion is no longer exist so this line will give a page fault (module-crash) 
			        upon fault/crash entire kernel mignt or might not crash depends on location of module.
			        but we cant rmmod or insmod the same module without resart, but other modules can be inserted or removed.  				    */
}

module_init(crash_module_init);
module_exit(crash_module_exit);
