#include <linux/init.h>
#include <linux/module.h>

MODULE_LICENSE("GPL");

void export_symbol_module_fun1(void)
{

	printk(KERN_ALERT "In %s() at line %d \n", __FUNCTION__, __LINE__);
}

EXPORT_SYMBOL(export_symbol_module_fun1);

__init int export_symbol_module_init(void)
{
	printk(KERN_ALERT "In %s() at line %d  \n", __FUNCTION__, __LINE__);
	return 0;
}

void export_symbol_module_exit(void)
{

	printk(KERN_ALERT "In %s() at line %d  \n", __FUNCTION__, __LINE__);
}

module_init(export_symbol_module_init);
module_exit(export_symbol_module_exit);
