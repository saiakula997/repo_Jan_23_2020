#include <linux/init.h>
#include <linux/module.h>

MODULE_LICENSE("GPL");

void export_symbol_module_fun1(void);
void using_symbol_module_fun1(void)
{

	printk(KERN_ALERT "In %s() at line %d \n", __FUNCTION__, __LINE__);
	export_symbol_module_fun1();
}


__init int using_symbol_module_init(void)
{
	printk(KERN_ALERT "In %s() at line %d  \n", __FUNCTION__, __LINE__);
	using_symbol_module_fun1();
	return 0;
}

void using_symbol_module_exit(void)
{

	printk(KERN_ALERT "In %s() at line %d  \n", __FUNCTION__, __LINE__);
}

module_init(using_symbol_module_init);
module_exit(using_symbol_module_exit);
