#include <linux/init.h>
#include <linux/module.h>
#include <linux/fs.h>

MODULE_LICENSE("GPL");

/* these functions declaration will be present in  /lib/modules/5.13.0-22-generic/build/include/linux/fs.h -> struct file_operations */
int simple_driver_open (struct inode * pinode, struct file *pfile)
ssize_t simple_driver_read (struct file *pfile , char __user *buffer , size_t size, loff_t *offset)
ssize_t simple_driver_write (struct file *pfile, const char __user *buffer, size_t size, loff_t * offset)
int simple_driver_release (struct inode *pinode, struct file *pfile)

int simple_driver_open (struct inode * pinode, struct file *pfile)
{
	printk(KERN_ALERT "In %s() ", __FUNCTION__);
	return 0;
}
ssize_t simple_driver_read (struct file *pfile , char __user *buffer , size_t size, loff_t *offset)
{
	printk(KERN_ALERT "In %s() ", __FUNCTION__);
	return size;
}

ssize_t simple_driver_write (struct file *pfile, const char __user *buffer, size_t size, loff_t * offset)
{
	printk(KERN_ALERT "In %s() ", __FUNCTION__);
	return size;
}

int simple_driver_release (struct inode *pinode, struct file *pfile)
{
	printk(KERN_ALERT "In %s() ", __FUNCTION__);
	return 0;
}

static const struct file_operations fops = {                          
	.owner   = THIS_MODULE,                                         
	.open    = simple_driver_open,                                     
	.release = simple_driver_release,                                 
	.read    = simple_driver_read,                                    
	.write   = simple_driver_write,                                   
};

__init int simple_driver_init(void)
{
	printk(KERN_ALERT "In %s() ", __FUNCTION__);
	register_chrdev(256, "simple_sai_driver", &fops);
	return 0;
}

void simple_driver_exit(void)
{
	printk(KERN_ALERT "In %s() ", __FUNCTION__);
	unregister_chrdev(256, "simple_sai_driver");
}

module_init(simple_driver_init);
module_exit(simple_driver_exit);
