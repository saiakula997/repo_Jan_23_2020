simple_driver.c [ simple character device driver]

sudo insmod simple_driver.ko  -> will insert a module into kernel

lsmod | grep "simple_driver"  ->

cat /proc/devices | grep "simple_sai_driver"  -> This will show the char device that is registered with Major number.

sudo mknod -m 666 /dev/simple_driver_file c 256 0 -> Now create a device file to perform read and write operations.

echo "hello" > /dev/simple_driver_file -> this will open write and close the file (verify in /var/log/syslog)

cat /dev/simple_driver_file -> this will open read and close the file (verify in /var/log/syslog)

sudo rmmod simple_driver -> will remove a module

sudo tail -f /var/log/syslog 

Note : `struct file_operations` in `/lib/modules/5.13.0-22-generic/build/include/linux/fs.h` contains the declaration of open, read, write, release (close) function handlers.

Note : `register_chrdrv` and `unregister_chrdrv` definitions will be present in `/lib/modules/5.13.0-22-generic/build/include/linux/fs.h`
 



