#include <linux/init.h>
#include <linux/module.h>
#include <linux/moduleparam.h>

MODULE_LICENSE("GPL");

int count = 1;
module_param(count, int, 444);


__init int module_params_init(void)
{
	printk(KERN_ALERT "In %s() at line %d \n", __FUNCTION__, __LINE__);
	printk(KERN_ALERT "Module param %d \n", count);
	return 0;
}

void module_params_exit(void)
{
	printk(KERN_ALERT "In %s() at line %d \n", __FUNCTION__, __LINE__);
}

module_init(module_params_init);
module_exit(module_params_exit);
