sudo insmod module_params.ko --> will take default count value 1
sudo insmod module_params.ko count=5 --> will take default count value 5

module_param(count, int, 777)  -> having the third parameter non zero will create below file and based on the permissions we can r/w on file.
cat /sys/module/module_params/parameters/count --> 1 by default (this will get upon module insertion) (we can chane the value at runtime idf we have right access)

